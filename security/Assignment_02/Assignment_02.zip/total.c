#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <openssl/aes.h>
#include <openssl/des.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>


#define BUFSIZE 64
char *base64(const unsigned char *input, int length);
int Base64Decode(char* b64message, char** buffer);
int calcDecodeLength(const char* b64input);

int main(){

    unsigned char in[BUFSIZE], out[BUFSIZE], back[BUFSIZE];
    unsigned char *e = out;
 
    DES_cblock key;
    DES_key_schedule keysched;
    char clear[] = "SKKU is the top university in the world";
    int clear_len = sizeof(clear)-1;
    /*
    unsigned char origin_key[] = {'0','0','0','0','9','9','6',
                         '5','6','c','1','6','f','8','e','8',
                         '4','f','5','0','d','1','0','a','6',
                         '5','0','5','5','c','3','d'};
        */
    
    unsigned char origin_key[] = {'0','0','0','0','9','9','6',
                         '5','6','c','1','6','f','8','e','8'};
        
    //unsigned char origin_key[]= {"000099656c16f8e84f50d10a65055c3d"};
    memset(in, 0, sizeof(in));
    memset(out, 0, sizeof(out));
    memset(back, 0, sizeof(back));
    
    memcpy(key,origin_key,8);
    DES_set_key((DES_cblock *)key, &keysched);
    //DES_set_key_checked((DES_cblock *)key, &keysched);
 
    /* 8 bytes of plaintext */
    strcpy(in, clear);
 
    printf("Plaintext: [%s]\n", in);
    unsigned char* base64_in;
    base64_in = (unsigned char*)malloc(sizeof(char)*BUFSIZE);
    memset(base64_in,0,BUFSIZE);

    base64_in = base64(in,clear_len);
    e= base64_in;
    printf("Plaintext with base64: [%s]\n", base64_in);

    int i=0;
    int iter=0;
    if(clear_len/16 * 16 != clear_len){
        iter = (clear_len/16+1)* 16;
    }else iter = (clear_len/16) *16;
    printf("iter : %d\n",iter);
    if(clear_len<iter) {
        //padding
        memset(in+clear_len,0x0,iter-clear_len);
    }
    for(i=0; i<iter; i+=8){
        DES_ecb_encrypt((DES_cblock *)(in+i),(DES_cblock *)(out+i), &keysched, DES_ENCRYPT);
    }

    base64_in = base64(out,iter);
    printf("i:%d\nCiphertext with base64:\n",i);
    //e = out;
    e = base64_in;
    i=0;
    while (*e) {
        i++;
        //printf("%02x ", *e++);
        printf("%c",*e++);
    }
    printf("\ni : %d\n",i);

    for(int i=0; i<=iter; i+=8){
        DES_ecb_encrypt((DES_cblock *)(out+i),(DES_cblock *)(back+i), &keysched, DES_DECRYPT);
    }

    printf("Decrypted Text : [%s]\n", back);

    AES_KEY enc_key_128;
    unsigned char aes_128_key[] = {0x00,0x00,0x00,0x1,0x2,0x4,0x5,
                0x3,0x5,0x0,0xb,0x5,0xe,0xb,0x0,
                0xa,0x1,0x5,0x4,0x8,0xf,0xc,0x6,
                0xd,0x2,0x7,0xd,0x3,0xb,0x4,0xd,0x1};
	unsigned char iv[AES_BLOCK_SIZE];
	memset(iv, 0x00, AES_BLOCK_SIZE);
// clear to be out
    unsigned char cipher[BUFSIZE];
    memset(cipher, 0, sizeof(cipher));
    memset(back, 0, sizeof(back));

    AES_set_encrypt_key(aes_128_key, sizeof(aes_128_key)*8, &enc_key_128);
    //AES_cbc_encrypt(out,cipher, sizeof(out), &enc_key_128, iv, AES_ENCRYPT);
    AES_cbc_encrypt(out,cipher, sizeof(out), &enc_key_128, iv, AES_ENCRYPT);
    unsigned char* base64_cipher = base64(cipher,sizeof(cipher));
    e= cipher;
    i=0;
    printf("cipertext:\n");
    while (*e) {
        i++;
        printf("%02x ", *e++);
        //printf("%c",*e++);
    }
    printf("\ni : %d\n",i);
    printf("Encrypted Text with DES,AES base64: [%s]\n", base64_cipher); 
	memset(iv, 0x00, AES_BLOCK_SIZE);   
    AES_KEY dec_key_128;
    AES_set_decrypt_key(aes_128_key, sizeof(aes_128_key)*8, &dec_key_128);
    AES_cbc_encrypt(cipher,back, sizeof(out), &dec_key_128, iv, AES_DECRYPT);
    base64_in = base64(back,sizeof(back));
    printf("Backward :\n");
    printf("%s",base64_in);
    /*
    e= back;
    while (*e) {
        i++;
        printf("%02x ", *e++);
        //printf("%c",*e++);
    }
    */
    printf("\n");
    return 0;
}


char *base64(const unsigned char *input, int length)
{
  BIO *bmem, *b64;
  BUF_MEM *bptr;

  b64 = BIO_new(BIO_f_base64());
  bmem = BIO_new(BIO_s_mem());
  b64 = BIO_push(b64, bmem);
  BIO_write(b64, input, length);
  BIO_flush(b64);
  BIO_get_mem_ptr(b64, &bptr);

  char *buff = (char *)malloc(bptr->length);
  memcpy(buff, bptr->data, bptr->length-1);
  buff[bptr->length-1] = 0;

  BIO_free_all(b64);

  return buff;
}
int calcDecodeLength(const char* b64input) { //Calculates the length of a decoded base64 string
  int len = strlen(b64input);
  int padding = 0;

  if (b64input[len-1] == '=' && b64input[len-2] == '=') //last two chars are =
    padding = 2;
  else if (b64input[len-1] == '=') //last char is =
    padding = 1;

  return (int)len*0.75 - padding;
}

int Base64Decode(char* b64message, char** buffer) { //Decodes a base64 encoded string
  BIO *bio, *b64;
  int decodeLen = calcDecodeLength(b64message),
      len = 0;
  *buffer = (char*)malloc(decodeLen+1);
  FILE* stream = fmemopen(b64message, strlen(b64message), "r");

  b64 = BIO_new(BIO_f_base64());
  bio = BIO_new_fp(stream, BIO_NOCLOSE);
  bio = BIO_push(b64, bio);
  BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL); //Do not use newlines to flush buffer
  len = BIO_read(bio, *buffer, strlen(b64message));
    //Can test here if len == decodeLen - if not, then return an error
  (*buffer)[len] = '\0';

  BIO_free_all(bio);
  fclose(stream);

  return (0); //success
}