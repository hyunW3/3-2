import sys
from time import sleep

serverPort = 10080

def server():
    """
    Write your code!!!
    """
    pass


"""
Don't touch the code below
"""
if  __name__ == '__main__':
    server()


