# RYU NAT Controller

based on https://groups.geni.net/geni/wiki/GENIExperimenter/Tutorials/OpenFlowNFVNAT

able to handle multiple NAT independently
mininet test available
