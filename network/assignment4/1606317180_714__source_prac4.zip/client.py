import sys

serverIP = '10.0.0.3'
serverPort = 10080
clientPort = 10081


def client(serverIP, serverPort, clientID):
    """
    Write your code!!!
    """
    pass


"""
Don't touch the code below!
"""
if  __name__ == '__main__':
    cleintID = input("")
    client(serverIP, serverPort, clientID)


